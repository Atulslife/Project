package cleaf;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Module1 {

	public static void main(String[] args) throws InterruptedException, IOException {
		System.setProperty("webdriver.chrome.driver", "c:\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://citrusleaf.in");
		driver.manage().window().maximize();
		driver.findElement(By.id("navbarDropdown")).click();
		Thread.sleep(3000);
		driver.findElement(By.partialLinkText("Development Services")).click();
		// driver.findElement(By.linkText("Contact")).click();
		driver.get("https://citrusleaf.in/contact");
		driver.findElement(By.id("contact-name")).sendKeys("atul mishra");
		driver.findElement(By.cssSelector("input[placeholder='Email*']")).sendKeys("mishraatul65@gmail.com");
		driver.findElement(By.name("skype_id")).sendKeys("Nil");
		driver.findElement(By.cssSelector("input[placeholder='Phone']")).sendKeys("9039817558");
		Select s = new Select(driver.findElement(By.cssSelector("select[class='form-control']")));
		s.selectByVisibleText("Website Design/Development");
		driver.findElement(By.id("contact-details")).sendKeys("nice");
		driver.findElement(By.cssSelector("button[id='submit-form']")).click();

		URL link = new URL("https://citrusleaf.in/ssss");
		HttpURLConnection c = (HttpURLConnection) link.openConnection();

		if (c.getResponseCode() == 404) {
			System.out.println(link + " − " + c.getResponseMessage());
		}
		driver.close();
	}

}
